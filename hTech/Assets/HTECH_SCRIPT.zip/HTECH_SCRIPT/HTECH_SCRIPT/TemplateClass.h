#pragma once
#include <ScriptObject.h>

StartScript(TemplateClass)

publicFunction Reset()
{

}

publicFunction Start()
{

}

publicFunction Update(float deltaTime)
{

}

EndScript(TemplateClass)