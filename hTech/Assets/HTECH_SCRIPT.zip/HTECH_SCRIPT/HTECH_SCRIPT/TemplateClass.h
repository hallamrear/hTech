#pragma once
#include <ScriptObject.h>

StartScript(TemplateClass)

publicFunction void Reset()
{

}

publicFunction void Start()
{

}

publicFunction void Update(float deltaTime)
{

}

EndScript(TemplateClass)