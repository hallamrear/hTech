#pragma once
class TemplateClass
{
};

